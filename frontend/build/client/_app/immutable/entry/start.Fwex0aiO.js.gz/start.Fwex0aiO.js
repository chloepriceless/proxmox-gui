import{l as o,a as r}from"../chunks/C41prowm.js";export{o as load_css,r as start};
