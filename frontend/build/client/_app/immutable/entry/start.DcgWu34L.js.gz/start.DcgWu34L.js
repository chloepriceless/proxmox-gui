import{l as o,a as r}from"../chunks/DOG61Hcx.js";export{o as load_css,r as start};
