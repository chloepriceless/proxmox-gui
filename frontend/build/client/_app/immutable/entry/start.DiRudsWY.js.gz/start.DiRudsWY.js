import{l as o,a as r}from"../chunks/4BoP6hY8.js";export{o as load_css,r as start};
