import{l as o,a as r}from"../chunks/BYsOGmcf.js";export{o as load_css,r as start};
