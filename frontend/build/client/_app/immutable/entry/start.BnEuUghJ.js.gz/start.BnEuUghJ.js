import{l as o,a as r}from"../chunks/B8PN7SMf.js";export{o as load_css,r as start};
